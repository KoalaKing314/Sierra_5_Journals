alert('Hello Mr. Davis.');
window.alert('Welcome To Kevins Journal For Feb 8th.');
window.confirm('Would You Like To Continue?');