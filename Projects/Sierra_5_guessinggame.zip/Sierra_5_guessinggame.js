var magic = Math.floor((Math.random() * 15) + 1);
var guess = prompt("Guess A Number! (Between One and 15)");
while (magic != guess){
    if (guess < magic){
        guess = prompt("You're Too Low! Try Again! -MLG Sanik");
        document.write("Low Fail!");
        color = "red";
    } else if (guess > magic){
        guess = prompt("Too High! Don't Do Drugs! Try Again!");
        document.write("High Fail!");
    } else {
        document.write("This Should Not Happen!");
    }
}
alert("YOU ARE THE WINNER MOUNTAIN DEW ALL AROUND!!!");
document.writeln("You Are The Real MVP!! (Win :p)");