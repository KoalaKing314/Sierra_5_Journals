alert('Howdy!')
window.alert('This is a window!')
window.confirm('Shall we continue?')
var r = confirm("Press a button");
if (r == true) {
        x = "You pressed OK!";
} else {
        x = "You pressed Cancel!";
}
var x = 42;
document.write(x);